// Seleciona todos os elementos com a classe 'card'
const cards = document.querySelectorAll('.card');

// Adiciona um evento de clique para cada um deles
cards.forEach(card => {
    card.addEventListener('click', () => {
        // Alterna a classe 'is-flipped' ao clicar
        card.classList.toggle('is-flipped');
    });
});